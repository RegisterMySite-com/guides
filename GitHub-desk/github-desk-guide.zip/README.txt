GitHub Desk client guide (RegisterMySite)
=========================================
Static site for Cloudflare Pages. Files sit at the zip root: index.html, 404.html, assets/...
Deploy the unzipped folder as the Pages output directory. Canonical URL:
https://github-desk-guide.registermysite.com/

assets/docs/github-desk-guide.pptx  PowerPoint, native editable text, speaker notes = narration script
assets/docs/github-desk-guide.pdf   PDF of the same deck
assets/audio/slide-01.mp3 ... slide-18.mp3  narration (en-GB-SoniaNeural), one clip per slide.
  Presenters using the .pptx: play the matching clip for each slide (audio is not embedded in the pptx).

The viewer's Narration button plays the current slide and moves on when each clip ends, until paused.
No credentials are included in this package.
