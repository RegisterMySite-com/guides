/* GitHub Desk client guide viewer (RegisterMySite) */
(function () {
  "use strict";

  var SLIDES = [
    {
      "title": "Put your HTML Studio site into GitHub Desk",
      "summary": "Title slide: the tattoo page in HTML Studio, and the same page imported into a GitHub Desk project folder.",
      "notes": "Hi, and welcome. In this guide I'll show you how to take a page you designed in HTML Studio and move it into GitHub Desk, as a project folder you can open, edit and preview. Everything you'll see comes from a real run with our demo business. We started from the Nightshade Tattoo template and renamed the brand to html-studio tattoo guide. Behind is the page in HTML Studio, and in front is the same page after we imported it into GitHub Desk."
    },
    {
      "title": "What GitHub Desk is",
      "summary": "A light companion desk for HTML Studio projects: folders, an HTML editor, a live preview, import from HTML Studio and export back.",
      "notes": "So what is GitHub Desk? It's a light companion desk for your HTML Studio projects. Number one, your work lives in project folders, and New Project Folder makes a fresh one. Two, Import from Studio brings an HTML Studio project in. Three, each folder opens in an HTML editor. Four, a live preview sits right beside the code, so you see your changes straight away. And five, Export to HTML Studio sends your work back again."
    },
    {
      "title": "The journey",
      "summary": "Seven steps from sign-up to an imported, editable project folder.",
      "notes": "Here's the whole trip on one slide, in seven steps. One, sign up for HTML Studio. Two, pick the Nightshade Tattoo template. Three, rename the brand in the sticky navigation. Four, make a Visitor Counter in Widget Studio and export it into that page. Five, save the canvas as a project, so it gets a project id. Six, create a project folder in GitHub Desk called html-studio-tattoos. And seven, import the page using that project id. The bar along the bottom of each slide shows which step we're on."
    },
    {
      "title": "Sign up for HTML Studio",
      "summary": "Name, email and password at html-studio.registermysite.com, then Create account.",
      "notes": "Step one, sign up. Go to html-studio dot registermysite dot com and open the sign-in window. Fill in your name, your email and a password, then click Create account. For this demo we used a Gmail plus address, which you can see on the slide. In our run there was no verification email to click. We were signed straight in. We never show the password in this guide, and please don't share yours either. A password manager is a good home for it."
    },
    {
      "title": "Choose the Nightshade Tattoo template",
      "summary": "Templates opens the catalog; Use in Studio loads Nightshade Tattoo into the canvas.",
      "notes": "Step two, choose the template. Click Templates in the top bar. The Website templates window shows the same catalog as registermysite dot com slash templates, with filters along the top. Our picture shows the top of the list, so scroll down to find Nightshade Tattoo, and choose Use in Studio. That loads it right into the canvas. On the right is the page once it's loaded: a dark, editorial tattoo studio site, with the brand still reading Nightshade Tattoo."
    },
    {
      "title": "Rename the sticky-nav brand",
      "summary": "Navigation section, Brand field set to exactly: html-studio tattoo guide, shown in the live preview.",
      "notes": "Step three, rename the brand. In Page sections on the left, click Navigation. That's the sticky nav section. In the editor, find the field called Brand, and change it to html-studio tattoo guide, all lowercase, exactly as you see it here. Now watch the live preview on the right. The name at the top of the page updates to html-studio tattoo guide. And the header says Saved, so the change is kept."
    },
    {
      "title": "Make a Visitor Counter in Widget Studio",
      "summary": "widget-studio.registermysite.com: Widget type Visitor Counter, theme and colors, preview, export buttons.",
      "notes": "Step four starts in Widget Studio, at widget-studio dot registermysite dot com. Under Widget type, choose Visitor Counter. You can pick a theme and colors if you like. The sandboxed preview shows the counter, called Live Visitors, with boxes for the last twenty four hours, the last seven days, the last thirty days, and total visits. When you're happy with it, use Export to HTML Studio at the top, or the Export, paste into HTML Studio button at the bottom left."
    },
    {
      "title": "Export the widget into your page",
      "summary": "The counter lands as a custom-embed section; honest note: the first export opened a blank, signed-out canvas.",
      "notes": "Back in HTML Studio, the widget arrives as a custom embed section near the bottom of the Page sections list. Click it, and you'll see its Embed HTML, and the widget type, which says counter. Now an honest note from our run. The first time we exported, HTML Studio opened a blank canvas that was signed out, so the widget had nowhere to go. We signed back in, exported again, and this time it landed in our tattoo page. So, sign in to HTML Studio before you export a widget. Notice the header still says No project id. That's our next step."
    },
    {
      "title": "Give the page a project id",
      "summary": "Gear, Projects, new project name, Create project from canvas; the header shows the new project id.",
      "notes": "Step five, give the page a project id. Click the gear icon to open Settings, and stay on the Projects tab. Type a new project name. Ours is html-studio tattoo guide. Then click Create project from canvas. A project card appears with that name and four files, and the header changes from No project id to an ID that starts with the letters P R J. Our full id is written on the slide. Copy yours, because GitHub Desk needs it in a moment."
    },
    {
      "title": "Honest note: the free plan limit",
      "summary": "Our first account was at Free plan 3/3 projects. We did not delete them; a new demo account was required.",
      "notes": "Here's something to check before you start. Our first account had already used its free plan: three of three projects, named Nightshade Tattoo, Guide Tattoo, and Tattoos. When we tried to create another one, HTML Studio said free accounts can create three projects, delete one or upgrade later to add more. We did not delete those projects. A new demo account was required, and that's the account behind the project id you saw on the last slide. If you hit this limit, you can delete a project you no longer need, or upgrade."
    },
    {
      "title": "Create the GitHub Desk folder",
      "summary": "github.registermysite.com: New Project Folder named html-studio-tattoos; it starts as an index.html skeleton.",
      "notes": "Step six happens in GitHub Desk, at github dot registermysite dot com. Use the same account you used in HTML Studio. On Workspace Projects, click New Project Folder, and name it html-studio-tattoos, with dashes and no spaces. GitHub Desk opens the new folder, with a green message: Project created with index dot html skeleton. There's one file, index dot html, a starter page in the editor, and a welcome page in the live preview. That's just a placeholder. Next, we'll fill it with our tattoo page."
    },
    {
      "title": "Import with the project id",
      "summary": "Import from HTML Studio: HTML Studio Project ID prj_mustb9jo_6t1q17601q, local name html-studio-tattoos, Imported 4 files.",
      "notes": "Step seven, the import. Inside the folder, click Import from HTML Studio along the top. In the window that opens, find the box called HTML Studio Project ID, and paste your project id, the one that starts with P R J. In New Local Project Name, type html-studio-tattoos. Then click Import from Studio. In our run, a green message said Imported 4 files from HTML Studio, and the file list filled up with index dot html, L L M S dot T X T, robots dot T X T, and sitemap dot X M L."
    },
    {
      "title": "A template name is not a project id",
      "summary": "Typing the slug nightshade-tattoo fails: Failed to import HTML Studio project: Project not found.",
      "notes": "Here's the mistake we made first, so you don't have to. We typed the template's name, nightshade-tattoo, into the HTML Studio Project ID box. GitHub Desk answered with a red message: Failed to import HTML Studio project, Project not found. That's because a template name is not a project id. The import only works with the id HTML Studio gives you when you create a project from the canvas, the one starting with P R J."
    },
    {
      "title": "Your page, now in GitHub Desk",
      "summary": "The imported folder: four files, the full page code, and the tattoo page with the brand html-studio tattoo guide.",
      "notes": "And here's the payoff. The html-studio-tattoos folder now holds the tattoo page. On the left are the four imported files. In the middle, index dot html has the full page code, far longer than the starter skeleton. And in the live preview on the right is the tattoo page, with our brand at the top: html-studio tattoo guide. The preview is narrow, so the name is cut short with dots, but it's all there. From here you can edit the code, click Save File, and use Open Tab for a bigger view."
    },
    {
      "title": "Tips",
      "summary": "Six practical tips: project id, free plan limit, sign in first, same account, folder names, brand versus page title.",
      "notes": "A few tips. Use the project id, not the template name. Ids start with P R J. Check your free plan before you begin. In our run the limit was three projects, and you'll find it under Settings, then Projects. Sign in before you export a widget, so it lands in your page and not a blank canvas. Use the same account on HTML Studio and GitHub Desk. Name folders with dashes, like html-studio-tattoos. And remember, the Brand field changes the name in the navigation, but the page title in the code still said Nightshade Tattoo. Edit it in GitHub Desk if you want it changed too."
    },
    {
      "title": "Troubleshooting",
      "summary": "Six real messages or issues from our run and what to do.",
      "notes": "Here are the real messages we saw, and what to do. Failed to import HTML Studio project, Project not found, means you typed a template name. Paste the project id instead. Free accounts can create three projects means you're at the limit. Delete one you don't need, or upgrade. A blank, signed-out canvas after exporting a widget means you weren't signed in. Sign in and export again. No project id in the header means the canvas isn't a project yet. Use Create project from canvas. Project created with index dot html skeleton is normal. It's the starter page, so go ahead and import. And if the brand looks cut off in the preview, it's just a narrow panel. Try Open Tab."
    },
    {
      "title": "Recap",
      "summary": "All seven steps in one list.",
      "notes": "Let's recap. Sign up at HTML Studio. Choose the Nightshade Tattoo template. Rename the brand to html-studio tattoo guide. Make a Visitor Counter in Widget Studio, and export it into the page while you're signed in. Create a project from the canvas to get your project id. In GitHub Desk, create the html-studio-tattoos folder. Then import with the project id, and your page is ready to edit and preview."
    },
    {
      "title": "Contact",
      "summary": "How to reach RegisterMySite.",
      "notes": "That's it from me. If you'd like a hand, we're happy to walk through this with you, from your first template to your GitHub Desk folder. You can find us at registermysite dot com, call 562 751 4597, or email info at registermysite dot com. We also meet in person in Los Angeles and Orange County. Thanks so much for your time, and happy building."
    }
  ];

  var TOTAL = SLIDES.length;
  var index = 0;
  var notesOpen = false;
  var presenting = false;
  var docMode = false;
  var touchStartX = 0;
  var touchStartY = 0;

  var stage = document.getElementById("stage");
  var rail = document.getElementById("rail");
  var notesPanel = document.getElementById("notes-panel");
  var notesBody = document.getElementById("notes-body");
  var notesKicker = document.getElementById("notes-kicker");
  var live = document.getElementById("live");
  var counter = document.getElementById("counter");
  var progressBar = document.getElementById("progress-bar");
  var btnPrev = document.getElementById("btn-prev");
  var btnNext = document.getElementById("btn-next");
  var btnPresent = document.getElementById("btn-present");
  var btnNotes = document.getElementById("btn-notes");
  var btnHelp = document.getElementById("btn-help");
  var btnDoc = document.getElementById("btn-doc");
  var btnSlides = document.getElementById("btn-slides");
  var welcome = document.getElementById("welcome");
  var helpOverlay = document.getElementById("help-overlay");
  var presentBar = document.getElementById("present-bar");
  var btnNarrate = document.getElementById("btn-narrate");
  var btnPresentNarrate = document.getElementById("btn-present-narrate");

  /* Narration: one mp3 per slide. Starts only when the user presses Play. */
  var audio = new Audio();
  audio.preload = "none";
  var narrating = false;
  var audioIndex = -1;

  function audioSrc(i) { return "assets/audio/slide-" + pad(i + 1) + ".mp3"; }

  function renderNarrate() {
    var label = narrating ? "Pause narration" : "Play narration for this slide";
    btnNarrate.setAttribute("aria-pressed", narrating ? "true" : "false");
    btnNarrate.setAttribute("aria-label", label);
    btnNarrate.innerHTML = narrating ? "❚❚ <span class=\"btn-label\">Pause</span>" : "▶ <span class=\"btn-label\">Narration</span>";
    if (btnPresentNarrate) {
      btnPresentNarrate.setAttribute("aria-pressed", narrating ? "true" : "false");
      btnPresentNarrate.textContent = narrating ? "❚❚" : "▶";
    }
  }

  function playSlideAudio(i, fromStart) {
    if (audioIndex !== i || fromStart) {
      audio.src = audioSrc(i);
      audioIndex = i;
    }
    var p = audio.play();
    if (p && p.catch) p.catch(function () { narrating = false; renderNarrate(); });
  }

  function startNarration() {
    narrating = true;
    renderNarrate();
    var resume = audioIndex === index && audio.currentTime > 0 && !audio.ended;
    playSlideAudio(index, !resume);
    live.textContent = "Narration playing: slide " + (index + 1);
  }

  function pauseNarration() {
    narrating = false;
    audio.pause();
    renderNarrate();
    live.textContent = "Narration paused";
  }

  function toggleNarration() {
    if (narrating) pauseNarration(); else startNarration();
  }

  audio.addEventListener("ended", function () {
    if (!narrating) return;
    if (index < TOTAL - 1) showSlide(index + 1);
    else { narrating = false; renderNarrate(); }
  });

  function pad(n) { return n < 10 ? "0" + n : String(n); }

  function parseHash() {
    var h = (location.hash || "").replace(/^#/, "");
    if (h === "document" || h === "pdf") return { mode: "doc", index: index };
    var m = h.match(/^(?:slide-)?(\d+)$/i);
    if (m) {
      var n = parseInt(m[1], 10);
      if (n >= 1 && n <= TOTAL) return { mode: "slides", index: n - 1 };
    }
    return { mode: "slides", index: 0 };
  }

  function setHash() {
    var next = docMode ? "document" : "slide-" + (index + 1);
    if ((location.hash || "").replace(/^#/, "") !== next) {
      history.replaceState(null, "", "#" + next);
    }
  }

  function preload(i) {
    if (i < 0 || i >= TOTAL) return;
    var img = new Image();
    img.src = "assets/slides/slide-" + pad(i + 1) + ".webp";
  }

  function announce() {
    var s = SLIDES[index];
    live.textContent = "Slide " + (index + 1) + " of " + TOTAL + ": " + s.title;
  }

  function renderNotes() {
    var s = SLIDES[index];
    notesKicker.textContent = "Slide " + (index + 1) + " — " + s.title;
    notesBody.textContent = s.notes;
  }

  function showSlide(i, opts) {
    opts = opts || {};
    if (i < 0) i = 0;
    if (i > TOTAL - 1) i = TOTAL - 1;
    index = i;
    var slides = stage.querySelectorAll(".slide");
    for (var n = 0; n < slides.length; n++) slides[n].classList.toggle("is-current", n === index);
    var thumbs = rail.querySelectorAll(".thumb");
    for (var t = 0; t < thumbs.length; t++) {
      thumbs[t].classList.toggle("is-current", t === index);
      if (t === index && thumbs[t].scrollIntoView) {
        thumbs[t].scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
      }
    }
    counter.textContent = (index + 1) + " / " + TOTAL;
    progressBar.style.width = ((index + 1) / TOTAL) * 100 + "%";
    btnPrev.disabled = index === 0;
    btnNext.disabled = index === TOTAL - 1;
    renderNotes();
    announce();
    preload(index + 1);
    preload(index - 1);
    if (!opts.skipHash) setHash();
    if (narrating && audioIndex !== index) playSlideAudio(index, true);
    else if (!narrating && audioIndex !== index && audioIndex !== -1) { audio.pause(); audioIndex = -1; }
  }

  function closeMenus() {
    var menu = document.getElementById("downloads-menu");
    if (menu) menu.open = false;
  }

  function setDocMode(on) {
    docMode = on;
    document.body.classList.toggle("doc-mode", on);
    btnDoc.setAttribute("aria-pressed", on ? "true" : "false");
    if (btnSlides) btnSlides.setAttribute("aria-pressed", on ? "false" : "true");
    var frame = document.getElementById("pdf-frame");
    if (frame) {
      frame.src = on ? "assets/docs/github-desk-guide.pdf#view=FitH" : "about:blank";
    }
    setHash();
    if (on && narrating) pauseNarration();
    if (on) live.textContent = "Document mode: PDF packet";
    else showSlide(index, { skipHash: true });
  }

  function setPresent(on) {
    presenting = on;
    document.body.classList.toggle("present", on);
    btnPresent.setAttribute("aria-pressed", on ? "true" : "false");
    if (on) {
      var el = document.documentElement;
      if (el.requestFullscreen) el.requestFullscreen().catch(function () {});
    } else if (document.fullscreenElement && document.exitFullscreen) {
      document.exitFullscreen().catch(function () {});
    }
  }

  function toggleNotes() {
    notesOpen = !notesOpen;
    notesPanel.classList.toggle("is-open", notesOpen);
    btnNotes.setAttribute("aria-pressed", notesOpen ? "true" : "false");
    if (notesOpen) notesPanel.focus();
  }

  function onKey(e) {
    if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    var k = e.key;
    if (k === "?" || (k === "/" && e.shiftKey)) {
      e.preventDefault();
      helpOverlay.hidden = !helpOverlay.hidden;
      return;
    }
    if (k === "Escape") {
      if (!helpOverlay.hidden) { helpOverlay.hidden = true; return; }
      if (!welcome.hidden) { welcome.hidden = true; return; }
      if (presenting) { setPresent(false); return; }
      if (notesOpen) { toggleNotes(); return; }
      return;
    }
    if (k === "ArrowRight" || k === "j" || k === "J" || k === "PageDown" || k === " ") {
      if (k === " ") e.preventDefault();
      if (!docMode) showSlide(index + 1);
      return;
    }
    if (k === "ArrowLeft" || k === "k" || k === "K" || k === "PageUp") {
      if (!docMode) showSlide(index - 1);
      return;
    }
    if (k === "Home") { if (!docMode) showSlide(0); return; }
    if (k === "End") { if (!docMode) showSlide(TOTAL - 1); return; }
    if (k === "f" || k === "F" || k === "p" || k === "P") {
      e.preventDefault();
      setPresent(!presenting);
      return;
    }
    if (k === "a" || k === "A") {
      e.preventDefault();
      if (!docMode) toggleNarration();
      return;
    }
    if (k === "n" || k === "N") {
      e.preventDefault();
      if (!docMode) toggleNotes();
    }
  }

  function onTouchStart(e) {
    if (!e.changedTouches || !e.changedTouches[0]) return;
    touchStartX = e.changedTouches[0].clientX;
    touchStartY = e.changedTouches[0].clientY;
  }
  function onTouchEnd(e) {
    if (!e.changedTouches || !e.changedTouches[0] || docMode) return;
    var dx = e.changedTouches[0].clientX - touchStartX;
    var dy = e.changedTouches[0].clientY - touchStartY;
    if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy)) return;
    if (dx < 0) showSlide(index + 1);
    else showSlide(index - 1);
  }

  function bind() {
    btnPrev.addEventListener("click", function () { showSlide(index - 1); });
    btnNext.addEventListener("click", function () { showSlide(index + 1); });
    btnPresent.addEventListener("click", function () { setPresent(!presenting); });
    var bpm = document.getElementById("btn-present-menu");
    if (bpm) bpm.addEventListener("click", function () { closeMenus(); setPresent(!presenting); });
    document.getElementById("btn-present-exit").addEventListener("click", function () { setPresent(false); });
    document.getElementById("btn-present-prev").addEventListener("click", function () { showSlide(index - 1); });
    document.getElementById("btn-present-next").addEventListener("click", function () { showSlide(index + 1); });
    btnNotes.addEventListener("click", toggleNotes);
    btnNarrate.addEventListener("click", toggleNarration);
    if (btnPresentNarrate) btnPresentNarrate.addEventListener("click", toggleNarration);
    btnHelp.addEventListener("click", function () { helpOverlay.hidden = !helpOverlay.hidden; closeMenus(); });
    btnDoc.addEventListener("click", function () { setDocMode(true); closeMenus(); });
    if (btnSlides) btnSlides.addEventListener("click", function () { setDocMode(false); closeMenus(); });
    document.getElementById("btn-welcome-close").addEventListener("click", function () {
      welcome.hidden = true;
      try { localStorage.setItem("rms-github-desk-guide-intro-v1", "1"); } catch (err) {}
    });
    document.getElementById("btn-help-close").addEventListener("click", function () { helpOverlay.hidden = true; });
    helpOverlay.addEventListener("click", function (e) {
      if (e.target === helpOverlay) helpOverlay.hidden = true;
    });
    rail.addEventListener("click", function (e) {
      var btn = e.target.closest("[data-slide]");
      if (!btn) return;
      setDocMode(false);
      showSlide(parseInt(btn.getAttribute("data-slide"), 10) - 1);
    });
    stage.addEventListener("touchstart", onTouchStart, { passive: true });
    stage.addEventListener("touchend", onTouchEnd, { passive: true });
    document.addEventListener("keydown", onKey);
    window.addEventListener("hashchange", function () {
      var st = parseHash();
      if (st.mode === "doc") setDocMode(true);
      else {
        if (docMode) setDocMode(false);
        showSlide(st.index, { skipHash: true });
      }
    });
    document.addEventListener("fullscreenchange", function () {
      if (!document.fullscreenElement && presenting) {
        document.body.classList.remove("present");
        presenting = false;
        btnPresent.setAttribute("aria-pressed", "false");
      }
    });
    var hideTimer;
    document.addEventListener("mousemove", function () {
      if (!presenting) return;
      presentBar.classList.add("is-visible");
      clearTimeout(hideTimer);
      hideTimer = setTimeout(function () { presentBar.classList.remove("is-visible"); }, 1600);
    });
  }

  function init() {
    document.documentElement.classList.add("js");
    var imgs = stage.querySelectorAll(".slide img");
    for (var i = 0; i < imgs.length; i++) {
      (function (el, n) {
        el.addEventListener("error", function () {
          el.closest(".slide").classList.add("is-missing");
        });
        el.alt = "Slide " + (n + 1) + " of " + TOTAL + ": " + SLIDES[n].title + " — " + SLIDES[n].summary;
      })(imgs[i], i);
    }
    bind();
    var st = parseHash();
    if (st.mode === "doc") { index = 0; setDocMode(true); }
    else showSlide(st.index);
    try {
      if (localStorage.getItem("rms-github-desk-guide-intro-v1") === "1") welcome.hidden = true;
      if (/[?&]intro=off(?:&|$)/.test(location.search)) welcome.hidden = true;
    } catch (err) {}
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
